/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questao05;

import implementacao.Aresta;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Reinaldo Dias
 */
public class Run {
        private static final int INF = Integer.MAX_VALUE;

    public static void main(String[] args) {
        try (BufferedReader br = new BufferedReader(new FileReader("src\\main\\java\\questao05\\Entrada.txt"))) {
            String cidadeOrigem = br.readLine();
            String cidadeDestino = br.readLine();
            
            Grafo grafo = lerGrafo(br);
            
            grafo.imprimirGrafo();
            int indiceOrigem = grafo.obterIndiceCidade((int) cidadeOrigem.charAt(0));
            int indiceDestino = grafo.obterIndiceCidade((int) cidadeDestino.charAt(0));

            int menorDistancia = floydWarshall(grafo, indiceOrigem, indiceDestino);

            if (menorDistancia == INF) {
                System.out.println("Não há rota entre as cidades.");
            } else {
                System.out.println("Menor distância entre " + cidadeOrigem + " e " + cidadeDestino + ": " + menorDistancia);
                System.out.println("Rota: " + reconstruirRota(grafo, indiceOrigem, indiceDestino));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static Grafo lerGrafo(BufferedReader br) throws IOException {
    Grafo grafo = new Grafo();
    String linha;
    while ((linha = br.readLine()) != null) {
        String[] vertices = linha.split(";");
        int v1 = (int) vertices[0].charAt(0);
        int v2 = (int) vertices[1].charAt(0);
        int peso = Integer.parseInt(vertices[2]);

        if (!grafo.verificaExistencia(v1)) {
            grafo.adicionarVertice(v1);
        }
        if (!grafo.verificaExistencia(v2)) {
            grafo.adicionarVertice(v2);
        }

        grafo.adicionarAresta(v1, v2, peso);
    }

    return grafo;
}


    private static int floydWarshall(Grafo grafo, int origem, int destino) {
        Map<Integer, Map<Integer, Integer>> matrizDistancias = new HashMap<>();

        for (int i = 0; i < grafo.getVertices().size(); i++) {
            matrizDistancias.put(i, new HashMap<>());
            for (int j = 0; j < grafo.getVertices().size(); j++) {
                if (i == j) {
                    matrizDistancias.get(i).put(j, 0);
                } else {
                    matrizDistancias.get(i).put(j, INF);
                }
            }
        }

        for (Aresta aresta : grafo.getArestas()) {
            int origemAresta = grafo.obterIndiceCidade(aresta.getOrigem().getNome().charAt(0));
            int destinoAresta = grafo.obterIndiceCidade(aresta.getDestino().getNome().charAt(0));
            matrizDistancias.get(origemAresta).put(destinoAresta, grafo.getVertices().get(origemAresta).getAresta().get(destinoAresta).getPeso());

        }

        for (int k = 0; k < grafo.getVertices().size(); k++) {
            for (int i = 0; i < grafo.getVertices().size(); i++) {
                for (int j = 0; j < grafo.getVertices().size(); j++) {
                    int distanciaIK = matrizDistancias.get(i).get(k);
                    int distanciaKJ = matrizDistancias.get(k).get(j);
                    int distanciaIJ = matrizDistancias.get(i).get(j);

                    if (distanciaIK != INF && distanciaKJ != INF && distanciaIK + distanciaKJ < distanciaIJ) {
                        matrizDistancias.get(i).put(j, distanciaIK + distanciaKJ);
                    }
                }
            }
        }

        return matrizDistancias.get(origem).get(destino);
    }

    private static String reconstruirRota(Grafo grafo, int origem, int destino) {
        if (origem == destino) {
            return grafo.getVertices().get(origem).getNome();
        } else {
            int proximoVertice = proximoVerticeIntermediario(grafo, origem, destino);
            return reconstruirRota(grafo, origem, proximoVertice) + " -> " + reconstruirRota(grafo, proximoVertice, destino);
        }
    }

    private static int proximoVerticeIntermediario(Grafo grafo, int origem, int destino) {
        for (int k = 0; k < grafo.getVertices().size(); k++) {
            int distanciaIK = grafo.getDistancia(origem, k);
            int distanciaKJ = grafo.getDistancia(k, destino);
            int distanciaIJ = grafo.getDistancia(origem, destino);

            if (distanciaIK != INF && distanciaKJ != INF && distanciaIK + distanciaKJ == distanciaIJ) {
                return k;
            }
        }
        return -1;
    }
}
            

