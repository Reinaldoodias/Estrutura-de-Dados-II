/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package implementacao;

import java.util.ArrayList;

/**
 *
 * @author Reinaldo Dias
 */
public class Vertice {
    private int id; //Identificador único e não nulo do vértice
    private String nome;
    private ArrayList<Vertice> adjacentes;
    private ArrayList<Aresta> arestas;
    private int valor;
    private int grau;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
   
    public Vertice(int valor){ //construtor para atribuir o valor do nó
        this.valor = valor;
        this.adjacentes = new ArrayList<>();
    }
    public int getId() {
        return id;
    } 
    public void setId(int id){
        this.id = id;
    }
    public int getValor(){
        return this.valor;
    }
    public ArrayList getAdjacentes(){
        return adjacentes;
    }
    public void inseriradjacente(Vertice ligado){
        adjacentes.add(ligado);
    }
    public void print(){
        for(Vertice v: adjacentes){
            System.out.print("(" + v.getValor()+")|");
        }
    }
    public void adiconaAresta(Aresta a){
        arestas.add(a);
    }
    public ArrayList<Aresta> getAresta(){
        return arestas;
    }
    public int getGrau(){
        return adjacentes.size();
    }
    public void setGrau(int grau){
        this.grau =grau;
    }

    public Object getArestaComDestino(int destinoAresta) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
}
