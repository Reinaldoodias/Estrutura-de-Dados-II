/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package implementacao;

/**
 *
 * @author Reinaldo Dias
 */
public class Aresta {
    private Vertice origem;
    private Vertice destino;
    private int peso;
    private int id;

    public Aresta(Vertice O, Vertice D, int peso) {
        this.origem = O;
        this.destino = D;
        this.peso = peso;
    }
    
    public int getPeso(){
        return peso;
    }
    public void setId(int id){
        this.id = id;
    }
    public int getId(){
        return this.id;
    }

    public Vertice getOrigem() {
        return origem;
    }

    public void setOrigem(Vertice origem) {
        this.origem = origem;
    }

    public Vertice getDestino() {
        return destino;
    }

    public void setDestino(Vertice destino) {
        this.destino = destino;
    }
   
    
}
