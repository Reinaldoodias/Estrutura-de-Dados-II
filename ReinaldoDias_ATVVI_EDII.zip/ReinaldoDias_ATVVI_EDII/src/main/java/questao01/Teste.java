/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questao01;

import implementacao.Grafo;

/**
 *
 * @author Reinaldo Dias
 */
public class Teste {
    public static void main(String[] args) {
        Grafo grafo = new Grafo();

        grafo.adicionarVertice(1);
        grafo.adicionarVertice(2);
        grafo.adicionarVertice(3);
        grafo.adicionarVertice(4);

        grafo.adicionarAresta(1, 2,10);
        grafo.adicionarAresta(1, 3,20);
        grafo.adicionarAresta(2, 4,70);
        grafo.adicionarAresta(3, 4,65);

        System.out.println("Grafo inicial:");
        grafo.imprimirGrafo();

        grafo.deleteVertice(2);
        System.out.println("\nGrafo após remover o Vértice 2:");
        grafo.imprimirGrafo();
    }
}
