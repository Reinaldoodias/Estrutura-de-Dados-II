package questao04;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;

public class Labirinto {
    private char[][] labirinto;
    private int linhas, colunas;
    private int entrada, saida;

    public Labirinto(String caminhoArquivo) throws FileNotFoundException {
        lerLabirinto(caminhoArquivo);
    }

    private void lerLabirinto(String caminhoArquivo) throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(caminhoArquivo));
        linhas = 0;

        while (scanner.hasNextLine()) {
            String linha = scanner.nextLine();
            colunas = linha.length();
            linhas++;
        }

        labirinto = new char[linhas][colunas];
        entrada = -1;
        saida = -1;

        scanner = new Scanner(new File(caminhoArquivo));

        for (int i = 0; i < linhas; i++) {
            String linha = scanner.nextLine();

            for (int j = 0; j < colunas; j++) {
                char c = linha.charAt(j);

                if (c == 'E') {
                    entrada = i * colunas + j;
                } else if (c == 'S') {
                    saida = i * colunas + j;
                }

                labirinto[i][j] = c;
            }
        }
    }

    public void resolverLabirinto() {
    Queue<Integer> fila = new LinkedList<>();
    boolean[] visitado = new boolean[linhas * colunas];
    int[] pai = new int[linhas * colunas];

    fila.add(entrada);
    visitado[entrada] = true;
    pai[entrada] = -1;

    List<Integer> caminhoEncontrado = null;

    while (!fila.isEmpty()) {
        int atual = fila.poll();

        if (atual == saida) {
            // Encontrou o caminho, reconstruir e imprimir
            caminhoEncontrado = imprimirCaminho(pai);
            break; // Interrompe o loop, pois encontrou o caminho
        }

        int linhaAtual = atual / colunas;
        int colunaAtual = atual % colunas;

        // Verificar vizinhos
        int[] movimentos = {-1, 0, 1, 0, -1};
        for (int k = 0; k < 4; k++) {
            int novaLinha = linhaAtual + movimentos[k];
            int novaColuna = colunaAtual + movimentos[k + 1];
            int novoVertice = novaLinha * colunas + novaColuna;

            if (ehMovimentoValido(novaLinha, novaColuna) && !visitado[novoVertice]) {
                fila.add(novoVertice);
                visitado[novoVertice] = true;
                pai[novoVertice] = atual;
            }
        }
    }

    if (caminhoEncontrado != null) {
        System.out.println("Caminho encontrado: " + caminhoEncontrado);
    } else {
        System.out.println("Não há caminho válido.");
    }
}


    private boolean ehMovimentoValido(int linha, int coluna) {
        return linha >= 0 && linha < linhas && coluna >= 0 && coluna < colunas && labirinto[linha][coluna] != 'X';
    }
    private List<Integer> imprimirCaminho(int[] pai) {
        List<Integer> caminho = new ArrayList<>();
        int atual = saida;

        while (atual != -1) {
            caminho.add(atual);
            atual = pai[atual];
        }

        Collections.reverse(caminho); // Inverte a ordem para começar do vértice de entrada
        return caminho;
}

}
