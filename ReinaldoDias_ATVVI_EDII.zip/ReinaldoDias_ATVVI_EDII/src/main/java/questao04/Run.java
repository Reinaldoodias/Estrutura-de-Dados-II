/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questao04;


import java.io.FileNotFoundException;
import java.util.List;


/**
 *
 * @author Reinaldo Dias
 */
public class Run {
    public static void main(String[] args) throws FileNotFoundException {
        String caminho = "src\\main\\java\\questao04\\Entrada.txt";
        Labirinto labirinto = new Labirinto(caminho);
        labirinto.resolverLabirinto();
       
    }
}
    


