/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questao04;
import implementacao.*;
import java.util.ArrayList;

        

/**
 *
 * @author Reinaldo Dias
 */
public class Grafo {
    private ArrayList<Vertice> vertices;//Array com todos os vértices
    private ArrayList<Aresta> arestas;
    
    public Grafo(){
        vertices = new ArrayList<>(); 
        arestas = new ArrayList<>();
    }
/**
 * Esse método é responsável por inserir um novo vertice no grafo
 * @param valor Refere-se ao valor do Vértice.
 */    
    public void adicionarVertice(int valor){
        Vertice novo = new Vertice(valor);
        vertices.add(novo); 
        novo.setId(vertices.indexOf(novo));
    }
    
    public Vertice buscarVertice(int valor){
        for(Vertice v : vertices){
            if(v.getValor()==valor){
                return v;
            }
        }
        return null;
    }
    
    
    public void deleteVertice(int valor){
        Vertice excluido = buscarVertice(valor);
        if(excluido!=null){
        arestas.removeIf(aresta-> aresta.getOrigem().equals(excluido) || aresta.getDestino().equals(excluido));
        for(Vertice v : vertices){
            v.getAdjacentes().remove(excluido);
        }
        excluido.getAdjacentes().clear();
        }else{
            System.out.println("Elemento não encontrado");
        }
    }
    
    public void adicionarAresta(int  idorigem, int iddestino, int peso){ 
        Vertice origem = buscarVertice(idorigem);
        Vertice destino = buscarVertice(iddestino);
        Aresta nova = new Aresta(origem,destino,peso); 
        arestas.add(nova);
        nova.setId(arestas.indexOf(nova));
        origem.inseriradjacente(destino);  
    }
    
    public Aresta buscarAresta(Vertice origem, Vertice destino){
        if(origem.getAdjacentes().isEmpty() || destino.getAdjacentes().isEmpty())
            return null;
        else
            for(Aresta a: arestas){
                if((a.getOrigem().equals(origem) && a.getDestino().equals(destino))||
                (a.getOrigem().equals(destino) && a.getDestino().equals(origem)));
                return a;
            }
        return null;
            
        
    }
    
    public void deleteAresta(int idOrigem, int idDestino){
        Vertice origem = buscarVertice(idOrigem);
        Vertice destino = buscarVertice(idDestino);
        Aresta excluida = buscarAresta(origem,destino);
        if(excluida!=null){
        arestas.remove(excluida);
        origem.getAdjacentes().remove(destino);
    }
    }
    public void imprimirvertices() {
       for(Vertice v : vertices){
           System.out.println("Teste:"+v.toString());
       }
    }
    public void imprimirGrafo() {
        Vertice a;
        System.out.println("\t|VERTICES    | ADJACENTES (VALOR)");
        System.out.println("\t|------------------------------");
        for (int i=0;i<vertices.size();i++){
            a = vertices.get(i);
            System.out.print("\t|Vértice (" + a.getId() + ") |"); a.print();System.out.print("\n");
        }
    }
    
    public boolean verificaExistencia(int valor){
        Vertice search = buscarVertice(valor);
        if(search!=null){
            return true;
        }else{
            return false;
        }
    }
    /*---------------------QUESTÃO 04--------------------*/
    public ArrayList<Integer> localizaCaminho(int tamanho){
        ArrayList<Integer> caminho = new ArrayList<>();
        Vertice entrada = buscarVertice(-1);
        if(entrada!=null){
            caminho.add(entrada.getId());
        }
        for(int i=0;i<tamanho;i++){
            for(int j=0;j<tamanho;j++){
                
            }
            Vertice temp = vertices.get(i);
            if(temp.getValor()==-2){
                return caminho;
            }else if(temp.getValor()==i){
               
            }
            caminho.add(temp.getId());
        }
        return caminho;
    }

}
