/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questao02;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Reinaldo Dias
 */
public class Run {
    public static void main(String[] args) {
        try{
            Grafo grafo = new Grafo();
            try (BufferedReader leitor = new BufferedReader(new FileReader("src\\main\\java\\questao02\\Entrada.txt"))) {
                String line;
                while((line=leitor.readLine())!=null){
                    String[] vertex = line.split(";");
                    int v1 = Integer.parseInt(vertex[0]);
                    int v2 = Integer.parseInt(vertex[1]);
                    if(grafo.verificaExistencia(v1)==false){
                        grafo.adicionarVertice(v1);
                    }
                    if(grafo.verificaExistencia(v2)==false){
                        grafo.adicionarVertice(v2);
                    }
                    grafo.adicionarAresta(v1, v2, 0);
                }
            }
            if(grafo.verificaCiclos()){
                System.out.println("POSSUI CICLO!");
            }  
            grafo.imprimirGrafo();

        }catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }
        
    }
}
