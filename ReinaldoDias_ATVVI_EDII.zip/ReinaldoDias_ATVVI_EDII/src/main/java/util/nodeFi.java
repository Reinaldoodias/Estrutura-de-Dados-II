package util;

/**
 * Classe que representa um nó da Fila
 * @author Reinaldo Dias
 * @param <T> Tipo de dado armazenado
 */
public class nodeFi<T>{
   private T dado;
   private nodeFi<T> proximo;
   /**
    * Construtor para inicializar os atributos
    * @param dado O dado do elemento
    */
    public nodeFi(T dado) {
        this.dado = dado;
        this.proximo = null;
    }
    //Getters e Setters
    public T getDado() {
        return dado;
    }

    public void setDado(T dado) {
        this.dado = dado;
    }

    public nodeFi getProximo() {
        return proximo;
    }

    public void setProximo(nodeFi proximo) {
        this.proximo = proximo;
    }
    
}
